import { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { CartItem, Product } from '../types';
import { useAuth } from './AuthContext';
import toast from 'react-hot-toast';

interface CartContextType {
  items: CartItem[];
  addToCart: (product: Product, quantity?: number) => Promise<void>;
  updateQuantity: (cartId: number, quantity: number) => Promise<void>;
  removeFromCart: (cartId: number) => Promise<void>;
  clearCart: () => void;
  total: number;
}

const CartContext = createContext<CartContextType | undefined>(undefined);

export function CartProvider({ children }: { children: ReactNode }) {
  const { user } = useAuth();
  const [items, setItems] = useState<CartItem[]>([]);

  const fetchCart = async () => {
    if (!user) {
      setItems([]);
      return;
    }
    const res = await fetch('/api/cart');
    if (res.ok) {
      const data = await res.json();
      setItems(data);
    }
  };

  useEffect(() => {
    if (user) {
      fetchCart();
    } else {
      const guestCart = JSON.parse(localStorage.getItem('guest_cart') || '[]');
      setItems(guestCart);
    }
  }, [user]);

  const addToCart = async (product: Product, quantity = 1) => {
    if (!user) {
      // Fallback to localStorage for guest users
      const guestCart = JSON.parse(localStorage.getItem('guest_cart') || '[]');
      const existingItemIndex = guestCart.findIndex((item: any) => item.product_id === product.id);
      
      if (existingItemIndex > -1) {
        guestCart[existingItemIndex].quantity += quantity;
      } else {
        guestCart.push({
          id: Date.now(), // temporary ID
          product_id: product.id,
          quantity,
          name: product.name,
          price: product.price,
          discount: product.discount,
          image_url: product.image_url
        });
      }
      
      localStorage.setItem('guest_cart', JSON.stringify(guestCart));
      setItems(guestCart);
      toast.success('Added to cart (Guest)');
      return;
    }
    const res = await fetch('/api/cart', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ product_id: product.id, quantity })
    });
    if (res.ok) {
      toast.success('Added to cart');
      fetchCart();
    }
  };

  const updateQuantity = async (cartId: number, quantity: number) => {
    if (quantity < 1) return;
    if (!user) {
      const guestCart = JSON.parse(localStorage.getItem('guest_cart') || '[]');
      const item = guestCart.find((i: any) => i.id === cartId);
      if (item) {
        item.quantity = quantity;
        localStorage.setItem('guest_cart', JSON.stringify(guestCart));
        setItems(guestCart);
      }
      return;
    }
    const res = await fetch(`/api/cart/${cartId}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ quantity })
    });
    if (res.ok) fetchCart();
  };

  const removeFromCart = async (cartId: number) => {
    if (!user) {
      const guestCart = JSON.parse(localStorage.getItem('guest_cart') || '[]');
      const filteredCart = guestCart.filter((i: any) => i.id !== cartId);
      localStorage.setItem('guest_cart', JSON.stringify(filteredCart));
      setItems(filteredCart);
      toast.success('Removed from cart');
      return;
    }
    const res = await fetch(`/api/cart/${cartId}`, { method: 'DELETE' });
    if (res.ok) {
      toast.success('Removed from cart');
      fetchCart();
    }
  };

  const clearCart = () => setItems([]);

  const total = items.reduce((acc, item) => {
    const price = item.price * (1 - item.discount / 100);
    return acc + price * item.quantity;
  }, 0);

  return (
    <CartContext.Provider value={{ items, addToCart, updateQuantity, removeFromCart, clearCart, total }}>
      {children}
    </CartContext.Provider>
  );
}

export const useCart = () => {
  const context = useContext(CartContext);
  if (!context) throw new Error('useCart must be used within CartProvider');
  return context;
};
