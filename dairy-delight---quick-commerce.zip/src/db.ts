import Database from 'better-sqlite3';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const db = new Database('dairy_delight.db');

// Initialize tables
db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    email TEXT UNIQUE NOT NULL,
    password TEXT,
    role TEXT DEFAULT 'user',
    google_id TEXT,
    meta_id TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS products (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    description TEXT,
    price REAL NOT NULL,
    discount INTEGER DEFAULT 0,
    image_url TEXT,
    category TEXT,
    stock INTEGER DEFAULT 0,
    is_available BOOLEAN DEFAULT 1,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS orders (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    guest_name TEXT,
    guest_email TEXT,
    total_amount REAL NOT NULL,
    payment_method TEXT NOT NULL,
    payment_status TEXT DEFAULT 'pending',
    delivery_status TEXT DEFAULT 'pending',
    address TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users (id)
  );

  CREATE TABLE IF NOT EXISTS order_items (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    order_id INTEGER NOT NULL,
    product_id INTEGER NOT NULL,
    quantity INTEGER NOT NULL,
    price REAL NOT NULL,
    FOREIGN KEY (order_id) REFERENCES orders (id),
    FOREIGN KEY (product_id) REFERENCES products (id)
  );

  CREATE TABLE IF NOT EXISTS cart (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    product_id INTEGER NOT NULL,
    quantity INTEGER DEFAULT 1,
    UNIQUE(user_id, product_id),
    FOREIGN KEY (user_id) REFERENCES users (id),
    FOREIGN KEY (product_id) REFERENCES products (id)
  );

  CREATE TABLE IF NOT EXISTS settings (
    key TEXT PRIMARY KEY,
    value TEXT
  );
`);

// Seed settings if empty
const settingsCount = db.prepare('SELECT COUNT(*) as count FROM settings').get() as { count: number };
if (settingsCount.count === 0) {
  const insertSetting = db.prepare('INSERT INTO settings (key, value) VALUES (?, ?)');
  insertSetting.run('brand_name', 'Dairy Delight');
  insertSetting.run('contact_email', 'support@dairydelight.com');
  insertSetting.run('contact_phone', '+91 98765 43210');
  insertSetting.run('address', '123 Chocolate Street, Mumbai, India');
}

// Seed initial products if empty
const productCount = db.prepare('SELECT COUNT(*) as count FROM products').get() as { count: number };
if (productCount.count === 0) {
  const insertProduct = db.prepare(`
    INSERT INTO products (name, description, price, discount, image_url, category, stock)
    VALUES (?, ?, ?, ?, ?, ?, ?)
  `);

  const initialProducts = [
    ['Dairy Milk Silk Bubbly', 'Soft and bubbly milk chocolate', 80, 10, 'https://picsum.photos/seed/bubbly/400/400', 'Silk', 100],
    ['Dairy Milk Fruit & Nut', 'Rich milk chocolate with fruits and nuts', 45, 5, 'https://picsum.photos/seed/fruitnut/400/400', 'Classic', 150],
    ['Dairy Milk Silk Oreo', 'Smooth milk chocolate with crunchy Oreo bits', 85, 15, 'https://picsum.photos/seed/oreo/400/400', 'Silk', 80],
    ['Dairy Milk Roasted Almond', 'Milk chocolate with roasted almonds', 50, 0, 'https://picsum.photos/seed/almond/400/400', 'Classic', 120],
    ['Dairy Milk Silk Hazelnut', 'Milk chocolate with whole hazelnuts', 90, 20, 'https://picsum.photos/seed/hazelnut/400/400', 'Silk', 60],
    ['Dairy Milk Crackle', 'Milk chocolate with rice crispies', 40, 0, 'https://picsum.photos/seed/crackle/400/400', 'Classic', 200],
  ];

  for (const p of initialProducts) {
    insertProduct.run(...p);
  }
}

// Seed admin user if not exists
const adminExists = db.prepare('SELECT * FROM users WHERE email = ?').get('admin1001') as any;
if (!adminExists) {
  const bcrypt = await import('bcryptjs');
  const hashedPassword = await bcrypt.default.hash('Password123', 10);
  db.prepare('INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, ?)').run('Admin User', 'admin1001', hashedPassword, 'admin');
}

export default db;
