import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'motion/react';
import { MapPin, CreditCard, Truck, CheckCircle, User } from 'lucide-react';
import { useCart } from '../contexts/CartContext';
import { useAuth } from '../contexts/AuthContext';
import toast from 'react-hot-toast';

declare const Razorpay: any;

export default function Checkout() {
  const { items, total, clearCart } = useCart();
  const { user } = useAuth();
  const [address, setAddress] = useState('');
  const [guestInfo, setGuestInfo] = useState({ name: '', email: '' });
  const [paymentMethod, setPaymentMethod] = useState<'upi' | 'cod'>('cod');
  const [isProcessing, setIsProcessing] = useState(false);
  const navigate = useNavigate();

  const handlePlaceOrder = async () => {
    if (!address) {
      toast.error('Please provide a delivery address');
      return;
    }

    if (!user && (!guestInfo.name || !guestInfo.email)) {
      toast.error('Please provide your name and email');
      return;
    }

    setIsProcessing(true);
    try {
      const res = await fetch('/api/orders', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          address,
          payment_method: paymentMethod,
          cart_items: items,
          guest_name: user ? null : guestInfo.name,
          guest_email: user ? null : guestInfo.email
        })
      });

      const data = await res.json();

      if (paymentMethod === 'upi' && data.rzpOrder) {
        // HINT: Ensure you have added the Razorpay script to your index.html
        // <script src="https://checkout.razorpay.com/v1/checkout.js"></script>
        const options = {
          key: import.meta.env.VITE_RAZORPAY_KEY_ID || 'rzp_test_dummy',
          amount: data.rzpOrder.amount,
          currency: 'INR',
          name: 'Dairy Delight',
          description: 'Chocolate Order',
          order_id: data.rzpOrder.id,
          handler: async function (response: any) {
            await fetch(`/api/orders/${data.orderId}/pay`, {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ razorpay_payment_id: response.razorpay_payment_id })
            });
            toast.success('Payment Successful!');
            clearCart();
            if (user) {
              navigate('/orders');
            } else {
              navigate('/thank-you', { state: { orderId: data.orderId } });
            }
          },
          prefill: {
            name: user?.name || guestInfo.name,
            email: user?.email || guestInfo.email
          },
          theme: { color: '#7c3aed' }
        };
        const rzp = new Razorpay(options);
        rzp.open();
      } else {
        toast.success('Order placed successfully!');
        clearCart();
        if (user) {
          navigate('/orders');
        } else {
          navigate('/thank-you', { state: { orderId: data.orderId } });
        }
      }
    } catch (err) {
      toast.error('Failed to place order');
    } finally {
      setIsProcessing(false);
    }
  };

  if (items.length === 0) {
    return (
      <div className="h-[calc(100vh-64px)] flex flex-col items-center justify-center space-y-4">
        <CheckCircle className="w-16 h-16 text-green-500" />
        <h2 className="text-2xl font-bold">Your cart is empty</h2>
        <button onClick={() => navigate('/')} className="text-purple-600 font-bold">Go Shopping</button>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 py-12 sm:px-6 lg:px-8">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
        {/* Left: Forms */}
        <div className="space-y-8">
          {!user && (
            <section className="bg-white p-8 rounded-3xl shadow-sm border border-gray-100 space-y-6">
              <div className="flex items-center space-x-3">
                <div className="p-2 bg-purple-50 rounded-lg text-purple-600">
                  <User className="w-6 h-6" />
                </div>
                <h2 className="text-xl font-bold">Contact Information</h2>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <input
                  type="text"
                  placeholder="Full Name"
                  value={guestInfo.name}
                  onChange={(e) => setGuestInfo({ ...guestInfo, name: e.target.value })}
                  className="w-full p-4 bg-gray-50 border border-gray-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-purple-500 transition-all"
                />
                <input
                  type="email"
                  placeholder="Email Address"
                  value={guestInfo.email}
                  onChange={(e) => setGuestInfo({ ...guestInfo, email: e.target.value })}
                  className="w-full p-4 bg-gray-50 border border-gray-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-purple-500 transition-all"
                />
              </div>
            </section>
          )}

          <section className="bg-white p-8 rounded-3xl shadow-sm border border-gray-100 space-y-6">
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-purple-50 rounded-lg text-purple-600">
                <MapPin className="w-6 h-6" />
              </div>
              <h2 className="text-xl font-bold">Delivery Address</h2>
            </div>
            <textarea
              required
              value={address}
              onChange={(e) => setAddress(e.target.value)}
              placeholder="Enter your full address with landmark..."
              className="w-full h-32 p-4 bg-gray-50 border border-gray-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-purple-500 transition-all"
            />
          </section>

          <section className="bg-white p-8 rounded-3xl shadow-sm border border-gray-100 space-y-6">
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-purple-50 rounded-lg text-purple-600">
                <CreditCard className="w-6 h-6" />
              </div>
              <h2 className="text-xl font-bold">Payment Method</h2>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <button
                onClick={() => setPaymentMethod('cod')}
                className={`p-4 rounded-2xl border-2 transition-all flex flex-col items-center space-y-2 ${
                  paymentMethod === 'cod' ? 'border-purple-600 bg-purple-50' : 'border-gray-100 hover:border-purple-200'
                }`}
              >
                <Truck className={`w-6 h-6 ${paymentMethod === 'cod' ? 'text-purple-600' : 'text-gray-400'}`} />
                <span className="font-bold">Cash on Delivery</span>
              </button>
              <button
                onClick={() => setPaymentMethod('upi')}
                className={`p-4 rounded-2xl border-2 transition-all flex flex-col items-center space-y-2 ${
                  paymentMethod === 'upi' ? 'border-purple-600 bg-purple-50' : 'border-gray-100 hover:border-purple-200'
                }`}
              >
                <CreditCard className={`w-6 h-6 ${paymentMethod === 'upi' ? 'text-purple-600' : 'text-gray-400'}`} />
                <span className="font-bold">UPI / Cards</span>
              </button>
            </div>
          </section>
        </div>

        {/* Right: Summary */}
        <div className="space-y-8">
          <section className="bg-white p-8 rounded-3xl shadow-sm border border-gray-100 sticky top-24">
            <h2 className="text-xl font-bold mb-6">Order Summary</h2>
            <div className="space-y-4 mb-6 max-h-60 overflow-y-auto">
              {items.map((item) => (
                <div key={item.id} className="flex justify-between items-center">
                  <div className="flex items-center space-x-3">
                    <img src={item.image_url} alt={item.name} className="w-12 h-12 rounded-lg object-cover" />
                    <div>
                      <p className="font-semibold text-gray-900">{item.name}</p>
                      <p className="text-sm text-gray-500">Qty: {item.quantity}</p>
                    </div>
                  </div>
                  <span className="font-bold">₹{(item.price * (1 - item.discount / 100) * item.quantity).toFixed(0)}</span>
                </div>
              ))}
            </div>
            <div className="border-t border-gray-100 pt-6 space-y-3">
              <div className="flex justify-between text-gray-600">
                <span>Subtotal</span>
                <span>₹{total.toFixed(0)}</span>
              </div>
              <div className="flex justify-between text-gray-600">
                <span>Delivery Fee</span>
                <span className="text-green-600 font-bold">FREE</span>
              </div>
              <div className="flex justify-between text-xl font-bold text-gray-900 pt-3">
                <span>Total</span>
                <span>₹{total.toFixed(0)}</span>
              </div>
            </div>
            <button
              onClick={handlePlaceOrder}
              disabled={isProcessing}
              className="w-full mt-8 py-4 bg-purple-600 text-white rounded-2xl font-bold hover:bg-purple-700 transition-all shadow-lg shadow-purple-200 disabled:opacity-50"
            >
              {isProcessing ? 'Processing...' : `Pay ₹${total.toFixed(0)}`}
            </button>
          </section>
        </div>
      </div>
    </div>
  );
}
