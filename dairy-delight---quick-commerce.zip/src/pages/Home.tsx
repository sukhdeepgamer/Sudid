import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'motion/react';
import { ShoppingCart, Star, Zap, Clock, Search } from 'lucide-react';
import { Product } from '../types';
import { useCart } from '../contexts/CartContext';

export default function Home() {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [settings, setSettings] = useState({ brand_name: 'Dairy Delight' });
  const { addToCart } = useCart();

  useEffect(() => {
    fetch('/api/products')
      .then(res => res.json())
      .then(data => {
        setProducts(data);
        setLoading(false);
      });

    fetch('/api/settings')
      .then(res => res.json())
      .then(data => {
        if (data && data.brand_name) {
          setSettings(data);
        }
      });
  }, []);

  const [searchQuery, setSearchQuery] = useState('');

  const filteredProducts = products.filter(p => 
    p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    p.category.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="space-y-12 pb-20">
      {/* Search Bar Mobile/Tablet Hint */}
      <div className="md:hidden px-4 pt-4">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 w-5 h-5" />
          <input
            type="text"
            placeholder="Search chocolates..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-4 py-3 bg-white border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-purple-500"
          />
        </div>
      </div>

      {/* Hero Section */}
      <section className="relative h-[500px] flex items-center overflow-hidden bg-purple-900">
        <div className="absolute inset-0 opacity-40">
          <img
            src="https://picsum.photos/seed/chocolate/1920/1080"
            alt="Hero Background"
            className="w-full h-full object-cover"
            referrerPolicy="no-referrer"
          />
        </div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="max-w-2xl text-white space-y-6"
          >
            <div className="inline-flex items-center space-x-2 px-3 py-1 bg-purple-500/30 backdrop-blur-md rounded-full border border-white/20">
              <Zap className="w-4 h-4 text-yellow-400 fill-yellow-400" />
              <span className="text-sm font-medium">Delivery in 10 minutes</span>
            </div>
            <h1 className="text-5xl md:text-7xl font-extrabold tracking-tight leading-tight">
              Indulge in <span className="text-purple-400">Pure Bliss</span>
            </h1>
            <p className="text-xl text-purple-100 max-w-lg">
              Get your favorite Dairy Milk chocolates delivered to your doorstep in minutes. Quick, fresh, and delicious.
            </p>
            <div className="flex space-x-4 pt-4">
              <button className="px-8 py-4 bg-white text-purple-900 rounded-xl font-bold hover:bg-purple-50 transition-all shadow-lg">
                Shop Now
              </button>
              <button className="px-8 py-4 bg-purple-600 text-white rounded-xl font-bold hover:bg-purple-700 transition-all border border-purple-500">
                View Offers
              </button>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Features */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {[
            { icon: Clock, title: '10 Min Delivery', desc: 'Lightning fast delivery to your door' },
            { icon: Star, title: 'Premium Quality', desc: 'Only the freshest Dairy Milk chocolates' },
            { icon: Zap, title: 'Best Prices', desc: 'Unbeatable discounts and offers' },
          ].map((feature, i) => (
            <div key={i} className="p-6 bg-white rounded-2xl border border-gray-100 shadow-sm flex items-start space-x-4">
              <div className="p-3 bg-purple-50 rounded-xl text-purple-600">
                <feature.icon className="w-6 h-6" />
              </div>
              <div>
                <h3 className="font-bold text-gray-900">{feature.title}</h3>
                <p className="text-gray-500 text-sm">{feature.desc}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Product Grid */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        <div className="flex justify-between items-end">
          <div>
            <h2 className="text-3xl font-bold text-gray-900">Popular Chocolates</h2>
            <p className="text-gray-500">Handpicked favorites for you</p>
          </div>
          <Link to="/products" className="text-purple-600 font-semibold hover:underline">View All</Link>
        </div>

        {loading ? (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            {[...Array(8)].map((_, i) => (
              <div key={i} className="animate-pulse bg-white rounded-2xl h-[350px] border border-gray-100" />
            ))}
          </div>
        ) : filteredProducts.length === 0 ? (
          <div className="text-center py-20 bg-white rounded-3xl border border-gray-100">
            <p className="text-gray-500">No chocolates found matching "{searchQuery}"</p>
          </div>
        ) : (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            {filteredProducts.map((product) => (
              <motion.div
                key={product.id}
                whileHover={{ y: -5 }}
                className="group bg-white rounded-2xl border border-gray-100 overflow-hidden shadow-sm hover:shadow-xl transition-all"
              >
                <div className="relative aspect-square overflow-hidden">
                  <img
                    src={product.image_url}
                    alt={product.name}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                  {product.discount > 0 && (
                    <div className="absolute top-3 left-3 px-2 py-1 bg-red-500 text-white text-xs font-bold rounded-lg">
                      {product.discount}% OFF
                    </div>
                  )}
                </div>
                <div className="p-4 space-y-2">
                  <div className="text-xs font-semibold text-purple-600 uppercase tracking-wider">
                    {product.category}
                  </div>
                  <h3 className="font-bold text-gray-900 truncate">{product.name}</h3>
                  <div className="flex items-center space-x-2">
                    <span className="text-lg font-bold text-gray-900">
                      ₹{(product.price * (1 - product.discount / 100)).toFixed(0)}
                    </span>
                    {product.discount > 0 && (
                      <span className="text-sm text-gray-400 line-through">₹{product.price}</span>
                    )}
                  </div>
                  <button
                    onClick={() => addToCart(product)}
                    className="w-full py-2.5 bg-purple-50 text-purple-600 rounded-xl font-bold hover:bg-purple-600 hover:text-white transition-all flex items-center justify-center space-x-2"
                  >
                    <ShoppingCart className="w-4 h-4" />
                    <span>Add to Cart</span>
                  </button>
                </div>
              </motion.div>
            ))}
          </div>
        )}
      </section>
    </div>
  );
}
