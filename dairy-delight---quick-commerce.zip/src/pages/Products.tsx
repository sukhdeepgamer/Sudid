import { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { ShoppingCart, Search, Filter, SlidersHorizontal } from 'lucide-react';
import { Product } from '../types';
import { useCart } from '../contexts/CartContext';

export default function Products() {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const { addToCart } = useCart();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');

  useEffect(() => {
    fetch('/api/products')
      .then(res => res.json())
      .then(data => {
        if (Array.isArray(data)) {
          setProducts(data);
        }
        setLoading(false);
      });
  }, []);

  const categories = ['All', 'Classic', 'Silk', 'Dark', 'Gifting'];

  const filteredProducts = products.filter(p => {
    const matchesSearch = p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         p.category.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = selectedCategory === 'All' || p.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-12">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div className="space-y-1">
          <h1 className="text-4xl font-bold text-gray-900">All Chocolates</h1>
          <p className="text-gray-500">Explore our full range of delicious treats</p>
        </div>
        
        <div className="flex flex-col sm:flex-row gap-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 w-5 h-5" />
            <input
              type="text"
              placeholder="Search chocolates..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full sm:w-64 pl-10 pr-4 py-3 bg-white border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-purple-500"
            />
          </div>
          <div className="flex items-center space-x-2 bg-white border border-gray-200 rounded-xl px-4 py-3">
            <Filter className="w-5 h-5 text-gray-400" />
            <select
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              className="bg-transparent focus:outline-none text-sm font-bold text-gray-700"
            >
              {categories.map(c => <option key={c} value={c}>{c}</option>)}
            </select>
          </div>
        </div>
      </div>

      {loading ? (
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-8">
          {[...Array(8)].map((_, i) => (
            <div key={i} className="animate-pulse bg-white rounded-3xl h-[400px] border border-gray-100 shadow-sm" />
          ))}
        </div>
      ) : filteredProducts.length === 0 ? (
        <div className="text-center py-32 bg-white rounded-[40px] border border-gray-100 shadow-sm">
          <div className="max-w-xs mx-auto space-y-4">
            <div className="w-20 h-20 bg-gray-50 rounded-full flex items-center justify-center mx-auto">
              <Search className="w-10 h-10 text-gray-300" />
            </div>
            <h3 className="text-xl font-bold text-gray-900">No results found</h3>
            <p className="text-gray-500">Try adjusting your search or filters to find what you're looking for.</p>
            <button 
              onClick={() => { setSearchQuery(''); setSelectedCategory('All'); }}
              className="px-6 py-2 text-purple-600 font-bold hover:bg-purple-50 rounded-xl transition-all"
            >
              Clear all filters
            </button>
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-8">
          {filteredProducts.map((product) => (
            <motion.div
              key={product.id}
              layout
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              whileHover={{ y: -8 }}
              className="group bg-white rounded-[32px] border border-gray-100 overflow-hidden shadow-sm hover:shadow-2xl transition-all duration-500"
            >
              <div className="relative aspect-[4/5] overflow-hidden">
                <img
                  src={product.image_url}
                  alt={product.name}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                />
                {product.discount > 0 && (
                  <div className="absolute top-4 left-4 px-3 py-1.5 bg-red-500 text-white text-xs font-black rounded-full shadow-lg">
                    {product.discount}% OFF
                  </div>
                )}
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500 flex items-end p-6">
                  <button
                    onClick={() => addToCart(product)}
                    className="w-full py-3 bg-white text-gray-900 rounded-2xl font-bold hover:bg-purple-600 hover:text-white transition-all shadow-xl flex items-center justify-center space-x-2 transform translate-y-4 group-hover:translate-y-0 transition-transform duration-500"
                  >
                    <ShoppingCart className="w-5 h-5" />
                    <span>Quick Add</span>
                  </button>
                </div>
              </div>
              <div className="p-6 space-y-3">
                <div className="flex justify-between items-start">
                  <span className="text-[10px] font-black text-purple-600 uppercase tracking-[0.2em]">
                    {product.category}
                  </span>
                  {!product.is_available && (
                    <span className="text-[10px] font-black text-red-500 uppercase tracking-[0.2em]">
                      Out of Stock
                    </span>
                  )}
                </div>
                <h3 className="font-bold text-gray-900 text-lg leading-tight group-hover:text-purple-600 transition-colors">
                  {product.name}
                </h3>
                <div className="flex items-center space-x-3">
                  <span className="text-2xl font-black text-gray-900">
                    ₹{(product.price * (1 - product.discount / 100)).toFixed(0)}
                  </span>
                  {product.discount > 0 && (
                    <span className="text-sm text-gray-400 line-through font-medium">₹{product.price}</span>
                  )}
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      )}
    </div>
  );
}
