import { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { TrendingUp, ShoppingBag, Users, DollarSign } from 'lucide-react';
import AdminSidebar from '../../components/AdminSidebar';
import { AdminStats } from '../../types';

export default function AdminDashboard() {
  const [stats, setStats] = useState<AdminStats | null>(null);

  useEffect(() => {
    fetch('/api/admin/stats')
      .then(res => res.json())
      .then(setStats);
  }, []);

  const cards = [
    { label: 'Total Sales', value: `₹${stats?.totalSales?.toFixed(0) || 0}`, icon: DollarSign, color: 'bg-green-500' },
    { label: 'Total Orders', value: stats?.totalOrders || 0, icon: ShoppingBag, color: 'bg-purple-500' },
    { label: 'Active Users', value: stats?.activeUsers || 0, icon: Users, color: 'bg-blue-500' },
    { label: 'Conversion', value: '12.5%', icon: TrendingUp, color: 'bg-orange-500' },
  ];

  return (
    <div className="flex">
      <AdminSidebar />
      <div className="flex-1 p-8 space-y-8">
        <div className="space-y-2">
          <h1 className="text-3xl font-bold text-gray-900">Admin Dashboard</h1>
          <p className="text-gray-500">Overview of your chocolate empire</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {cards.map((card, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.1 }}
              className="bg-white p-6 rounded-3xl border border-gray-100 shadow-sm space-y-4"
            >
              <div className={`w-12 h-12 ${card.color} rounded-2xl flex items-center justify-center text-white shadow-lg`}>
                <card.icon className="w-6 h-6" />
              </div>
              <div>
                <p className="text-sm font-bold text-gray-400 uppercase tracking-wider">{card.label}</p>
                <p className="text-3xl font-bold text-gray-900">{card.value}</p>
              </div>
            </motion.div>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div className="bg-white p-8 rounded-3xl border border-gray-100 shadow-sm h-80 flex items-center justify-center">
            <p className="text-gray-400 font-medium italic">Sales Chart Placeholder</p>
          </div>
          <div className="bg-white p-8 rounded-3xl border border-gray-100 shadow-sm h-80 flex items-center justify-center">
            <p className="text-gray-400 font-medium italic">User Growth Chart Placeholder</p>
          </div>
        </div>
      </div>
    </div>
  );
}
