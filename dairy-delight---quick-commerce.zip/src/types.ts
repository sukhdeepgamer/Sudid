export interface User {
  id: number;
  name: string;
  email: string;
  role: 'user' | 'admin';
}

export interface Product {
  id: number;
  name: string;
  description: string;
  price: number;
  discount: number;
  image_url: string;
  category: string;
  stock: number;
  is_available: boolean;
}

export interface CartItem extends Product {
  cart_id: number;
  quantity: number;
}

export interface Order {
  id: number;
  user_id: number;
  user_name?: string;
  total_amount: number;
  payment_method: string;
  payment_status: string;
  delivery_status: string;
  address: string;
  created_at: string;
}

export interface AdminStats {
  totalSales: number;
  totalOrders: number;
  activeUsers: number;
}
