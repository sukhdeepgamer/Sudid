import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Facebook, Twitter, Instagram, Mail, Phone, MapPin } from 'lucide-react';

export default function Footer() {
  const [settings, setSettings] = useState({
    brand_name: 'Dairy Delight',
    contact_email: 'support@dairydelight.com',
    contact_phone: '+91 1800-CHOCO-LOVE',
    address: 'Chocolate Factory, Mumbai, India'
  });

  useEffect(() => {
    fetch('/api/settings')
      .then(res => res.json())
      .then(data => {
        if (data && data.brand_name) {
          setSettings(data);
        }
      })
      .catch(() => {});
  }, []);

  return (
    <footer className="bg-white border-t border-gray-100 pt-16 pb-24 md:pb-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12">
          {/* Brand */}
          <div className="space-y-6">
            <Link to="/" className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-purple-600 rounded-lg flex items-center justify-center">
                <span className="text-white font-bold text-lg">{settings.brand_name[0]}</span>
              </div>
              <span className="text-lg font-bold bg-gradient-to-r from-purple-600 to-indigo-600 bg-clip-text text-transparent">
                {settings.brand_name}
              </span>
            </Link>
            <p className="text-gray-500 text-sm leading-relaxed">
              Bringing the world's favorite milk chocolate to your doorstep in 10 minutes. Fresh, fast, and always delicious.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="p-2 bg-gray-50 text-gray-400 hover:text-purple-600 rounded-lg transition-colors">
                <Facebook className="w-5 h-5" />
              </a>
              <a href="#" className="p-2 bg-gray-50 text-gray-400 hover:text-purple-600 rounded-lg transition-colors">
                <Instagram className="w-5 h-5" />
              </a>
              <a href="#" className="p-2 bg-gray-50 text-gray-400 hover:text-purple-600 rounded-lg transition-colors">
                <Twitter className="w-5 h-5" />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-bold text-gray-900 mb-6">Quick Links</h4>
            <ul className="space-y-4 text-sm text-gray-500">
              <li><Link to="/" className="hover:text-purple-600 transition-colors">Home</Link></li>
              <li><Link to="/orders" className="hover:text-purple-600 transition-colors">My Orders</Link></li>
              <li><Link to="/login" className="hover:text-purple-600 transition-colors">Login / Signup</Link></li>
              <li><Link to="/admin" className="hover:text-purple-600 transition-colors">Admin Panel</Link></li>
            </ul>
          </div>

          {/* Categories */}
          <div>
            <h4 className="font-bold text-gray-900 mb-6">Categories</h4>
            <ul className="space-y-4 text-sm text-gray-500">
              <li><a href="#" className="hover:text-purple-600 transition-colors">Classic Milk</a></li>
              <li><a href="#" className="hover:text-purple-600 transition-colors">Silk Collection</a></li>
              <li><a href="#" className="hover:text-purple-600 transition-colors">Dark Chocolate</a></li>
              <li><a href="#" className="hover:text-purple-600 transition-colors">Gift Packs</a></li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="font-bold text-gray-900 mb-6">Contact Us</h4>
            <ul className="space-y-4 text-sm text-gray-500">
              <li className="flex items-center space-x-3">
                <Mail className="w-4 h-4 text-purple-600" />
                <span>{settings.contact_email}</span>
              </li>
              <li className="flex items-center space-x-3">
                <Phone className="w-4 h-4 text-purple-600" />
                <span>{settings.contact_phone}</span>
              </li>
              <li className="flex items-center space-x-3">
                <MapPin className="w-4 h-4 text-purple-600" />
                <span>{settings.address}</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-16 pt-8 border-t border-gray-100 flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0 text-xs text-gray-400 font-medium uppercase tracking-widest">
          <p>© {new Date().getFullYear()} {settings.brand_name}. All rights reserved.</p>
          <div className="flex space-x-8">
            <a href="#" className="hover:text-purple-600">Privacy Policy</a>
            <a href="#" className="hover:text-purple-600">Terms of Service</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
