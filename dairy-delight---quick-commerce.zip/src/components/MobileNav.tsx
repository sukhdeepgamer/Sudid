import React from 'react';
import { Link } from 'react-router-dom';
import { Home, Search, ShoppingBag, User } from 'lucide-react';
import { useCart } from '../contexts/CartContext';
import { useAuth } from '../contexts/AuthContext';

export default function MobileNav() {
  const { items } = useCart();
  const { user } = useAuth();

  return (
    <nav className="md:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-gray-100 px-6 py-3 z-50 flex justify-between items-center shadow-[0_-4px_10px_rgba(0,0,0,0.05)]">
      <Link to="/" className="flex flex-col items-center space-y-1 text-gray-400 hover:text-purple-600 transition-colors">
        <Home className="w-6 h-6" />
        <span className="text-[10px] font-bold uppercase tracking-wider">Home</span>
      </Link>
      <button className="flex flex-col items-center space-y-1 text-gray-400 hover:text-purple-600 transition-colors">
        <Search className="w-6 h-6" />
        <span className="text-[10px] font-bold uppercase tracking-wider">Search</span>
      </button>
      <Link to="/orders" className="flex flex-col items-center space-y-1 text-gray-400 hover:text-purple-600 transition-colors">
        <ShoppingBag className="w-6 h-6" />
        <span className="text-[10px] font-bold uppercase tracking-wider">Orders</span>
      </Link>
      {user?.role === 'admin' && (
        <Link to="/admin" className="flex flex-col items-center space-y-1 text-purple-600 transition-colors">
          <User className="w-6 h-6" />
          <span className="text-[10px] font-bold uppercase tracking-wider">Admin</span>
        </Link>
      )}
      <Link to={user ? (user.role === 'admin' ? '/admin' : '/orders') : '/login'} className="flex flex-col items-center space-y-1 text-gray-400 hover:text-purple-600 transition-colors">
        <User className="w-6 h-6" />
        <span className="text-[10px] font-bold uppercase tracking-wider">{user ? 'Profile' : 'Login'}</span>
      </Link>
      
      {/* Floating Cart Badge for Mobile */}
      {items.length > 0 && (
        <div className="absolute -top-12 left-1/2 -translate-x-1/2">
          <Link to="/checkout" className="bg-purple-600 text-white px-4 py-2 rounded-full shadow-lg flex items-center space-x-2 animate-bounce">
            <ShoppingBag className="w-4 h-4" />
            <span className="text-xs font-bold">{items.length} Items</span>
          </Link>
        </div>
      )}
    </nav>
  );
}
