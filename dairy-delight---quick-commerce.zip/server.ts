import express from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import { fileURLToPath } from 'url';
import cookieParser from 'cookie-parser';
import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';
import db from './src/db.ts';
import Razorpay from 'razorpay';
import multer from 'multer';
import fs from 'fs';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const JWT_SECRET = process.env.JWT_SECRET || 'fallback_secret';
const PORT = 3000;

// Ensure uploads directory exists
const uploadDir = path.join(__dirname, 'public', 'uploads');
if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir, { recursive: true });
}

// Multer config
const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, uploadDir),
  filename: (req, file, cb) => cb(null, Date.now() + '-' + file.originalname)
});
const upload = multer({ storage });

async function startServer() {
  const app = express();
  app.use(express.json());
  app.use(cookieParser());
  app.use('/uploads', express.static(uploadDir));

  // Razorpay instance
  const razorpay = new Razorpay({
    key_id: process.env.RAZORPAY_KEY_ID || 'rzp_test_dummy',
    key_secret: process.env.RAZORPAY_KEY_SECRET || 'dummy_secret'
  });

  // --- Middleware ---
  const authenticate = (req: any, res: any, next: any) => {
    const token = req.cookies.token;
    if (!token) return res.status(401).json({ error: 'Unauthorized' });
    try {
      const decoded = jwt.verify(token, JWT_SECRET) as any;
      req.user = decoded;
      next();
    } catch (err) {
      res.status(401).json({ error: 'Invalid token' });
    }
  };

  const isAdmin = (req: any, res: any, next: any) => {
    if (req.user?.role !== 'admin') return res.status(403).json({ error: 'Forbidden' });
    next();
  };

  const optionalAuthenticate = (req: any, res: any, next: any) => {
    const token = req.cookies.token;
    if (token) {
      try {
        const decoded = jwt.verify(token, JWT_SECRET) as any;
        req.user = decoded;
      } catch (err) {
        // Ignore invalid token for optional auth
      }
    }
    next();
  };

  // --- Auth Routes ---
  app.post('/api/auth/signup', async (req, res) => {
    const { name, email, password } = req.body;
    try {
      const hashedPassword = await bcrypt.hash(password, 10);
      const result = db.prepare('INSERT INTO users (name, email, password) VALUES (?, ?, ?)').run(name, email, hashedPassword);
      const token = jwt.sign({ id: result.lastInsertRowid, email, role: 'user' }, JWT_SECRET);
      res.cookie('token', token, { httpOnly: true, secure: true, sameSite: 'none' });
      res.json({ user: { id: result.lastInsertRowid, name, email, role: 'user' } });
    } catch (err: any) {
      res.status(400).json({ error: err.message.includes('UNIQUE') ? 'Email already exists' : 'Signup failed' });
    }
  });

  app.post('/api/auth/login', async (req, res) => {
    const { email, password } = req.body;
    const user = db.prepare('SELECT * FROM users WHERE email = ?').get(email) as any;
    if (!user || !(await bcrypt.compare(password, user.password))) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }
    const token = jwt.sign({ id: user.id, email: user.email, role: user.role }, JWT_SECRET);
    res.cookie('token', token, { httpOnly: true, secure: true, sameSite: 'none' });
    res.json({ user: { id: user.id, name: user.name, email: user.email, role: user.role } });
  });

  app.post('/api/auth/logout', (req, res) => {
    res.clearCookie('token');
    res.json({ message: 'Logged out' });
  });

  app.get('/api/auth/me', authenticate, (req: any, res) => {
    const user = db.prepare('SELECT id, name, email, role FROM users WHERE id = ?').get(req.user.id);
    res.json({ user });
  });

  // --- Product Routes ---
  app.get('/api/products', (req, res) => {
    const products = db.prepare('SELECT * FROM products WHERE is_available = 1').all();
    res.json(products);
  });

  app.get('/api/admin/products', authenticate, isAdmin, (req, res) => {
    const products = db.prepare('SELECT * FROM products').all();
    res.json(products);
  });

  app.post('/api/admin/products', authenticate, isAdmin, upload.single('image'), (req, res) => {
    const { name, description, price, discount, category, stock, is_available } = req.body;
    const imageUrl = req.file ? `/uploads/${req.file.filename}` : req.body.image_url;
    const result = db.prepare(`
      INSERT INTO products (name, description, price, discount, image_url, category, stock, is_available)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `).run(name, description, price, discount, imageUrl, category, stock, is_available === 'false' ? 0 : 1);
    res.json({ id: result.lastInsertRowid });
  });

  app.put('/api/admin/products/:id', authenticate, isAdmin, upload.single('image'), (req, res) => {
    const { name, description, price, discount, category, stock, is_available } = req.body;
    const imageUrl = req.file ? `/uploads/${req.file.filename}` : req.body.image_url;
    db.prepare(`
      UPDATE products 
      SET name = ?, description = ?, price = ?, discount = ?, image_url = ?, category = ?, stock = ?, is_available = ?
      WHERE id = ?
    `).run(name, description, price, discount, imageUrl, category, stock, is_available === 'true' ? 1 : 0, req.params.id);
    res.json({ success: true });
  });

  app.delete('/api/admin/products/:id', authenticate, isAdmin, (req, res) => {
    db.prepare('DELETE FROM products WHERE id = ?').run(req.params.id);
    res.json({ success: true });
  });

  // --- Cart Routes ---
  app.get('/api/cart', authenticate, (req: any, res) => {
    const items = db.prepare(`
      SELECT c.*, p.name, p.price, p.discount, p.image_url 
      FROM cart c 
      JOIN products p ON c.product_id = p.id 
      WHERE c.user_id = ?
    `).all(req.user.id);
    res.json(items);
  });

  app.post('/api/cart', authenticate, (req: any, res) => {
    const { product_id, quantity } = req.body;
    db.prepare(`
      INSERT INTO cart (user_id, product_id, quantity) 
      VALUES (?, ?, ?) 
      ON CONFLICT(user_id, product_id) DO UPDATE SET quantity = quantity + EXCLUDED.quantity
    `).run(req.user.id, product_id, quantity || 1);
    res.json({ success: true });
  });

  app.put('/api/cart/:id', authenticate, (req: any, res) => {
    const { quantity } = req.body;
    db.prepare('UPDATE cart SET quantity = ? WHERE id = ? AND user_id = ?').run(quantity, req.params.id, req.user.id);
    res.json({ success: true });
  });

  app.delete('/api/cart/:id', authenticate, (req: any, res) => {
    db.prepare('DELETE FROM cart WHERE id = ? AND user_id = ?').run(req.params.id, req.user.id);
    res.json({ success: true });
  });

  // --- Order Routes ---
  app.post('/api/orders', optionalAuthenticate, async (req: any, res) => {
    const { address, payment_method, cart_items, guest_name, guest_email } = req.body;
    const total_amount = cart_items.reduce((acc: number, item: any) => {
      const price = item.price * (1 - item.discount / 100);
      return acc + price * item.quantity;
    }, 0);

    const transaction = db.transaction(() => {
      const orderResult = db.prepare(`
        INSERT INTO orders (user_id, guest_name, guest_email, total_amount, payment_method, address) 
        VALUES (?, ?, ?, ?, ?, ?)
      `).run(req.user?.id || null, guest_name || null, guest_email || null, total_amount, payment_method, address);
      
      const orderId = orderResult.lastInsertRowid;
      const insertItem = db.prepare(`
        INSERT INTO order_items (order_id, product_id, quantity, price) 
        VALUES (?, ?, ?, ?)
      `);

      for (const item of cart_items) {
        const price = item.price * (1 - item.discount / 100);
        insertItem.run(orderId, item.product_id, item.quantity, price);
        // Update stock
        db.prepare('UPDATE products SET stock = stock - ? WHERE id = ?').run(item.quantity, item.product_id);
      }

      // Clear cart
      db.prepare('DELETE FROM cart WHERE user_id = ?').run(req.user.id);

      return orderId;
    });

    try {
      const orderId = transaction();
      if (payment_method === 'upi') {
        const options = {
          amount: Math.round(total_amount * 100),
          currency: 'INR',
          receipt: `order_${orderId}`
        };
        const rzpOrder = await razorpay.orders.create(options);
        return res.json({ orderId, rzpOrder });
      }
      res.json({ orderId });
    } catch (err) {
      res.status(500).json({ error: 'Order creation failed' });
    }
  });

  app.post('/api/orders/:id/pay', optionalAuthenticate, (req: any, res) => {
    // In a real app, you would verify the signature here
    const userId = req.user?.id || null;
    if (userId) {
      db.prepare('UPDATE orders SET payment_status = "paid" WHERE id = ? AND user_id = ?').run(req.params.id, userId);
    } else {
      db.prepare('UPDATE orders SET payment_status = "paid" WHERE id = ? AND user_id IS NULL').run(req.params.id);
    }
    res.json({ success: true });
  });

  app.get('/api/orders', authenticate, (req: any, res) => {
    const orders = db.prepare('SELECT * FROM orders WHERE user_id = ? ORDER BY created_at DESC').all(req.user.id);
    res.json(orders);
  });

  app.get('/api/admin/orders', authenticate, isAdmin, (req, res) => {
    const orders = db.prepare(`
      SELECT o.*, COALESCE(u.name, o.guest_name) as user_name 
      FROM orders o 
      LEFT JOIN users u ON o.user_id = u.id 
      ORDER BY o.created_at DESC
    `).all();
    res.json(orders);
  });

  app.put('/api/admin/orders/:id', authenticate, isAdmin, (req, res) => {
    const { delivery_status, payment_status } = req.body;
    db.prepare('UPDATE orders SET delivery_status = ?, payment_status = ? WHERE id = ?')
      .run(delivery_status, payment_status, req.params.id);
    res.json({ success: true });
  });

  // --- Dashboard Stats ---
  app.get('/api/admin/stats', authenticate, isAdmin, (req, res) => {
    const totalSales = db.prepare('SELECT SUM(total_amount) as total FROM orders WHERE payment_status = "paid" OR payment_method = "cod"').get() as any;
    const totalOrders = db.prepare('SELECT COUNT(*) as count FROM orders').get() as any;
    const activeUsers = db.prepare('SELECT COUNT(*) as count FROM users').get() as any;
    res.json({
      totalSales: totalSales.total || 0,
      totalOrders: totalOrders.count,
      activeUsers: activeUsers.count
    });
  });

  app.post('/api/admin/change-password', authenticate, isAdmin, async (req: any, res) => {
    const { currentPassword, newPassword } = req.body;
    const user = db.prepare('SELECT * FROM users WHERE id = ?').get(req.user.id) as any;
    
    if (!user || !(await bcrypt.compare(currentPassword, user.password))) {
      return res.status(401).json({ error: 'Invalid current password' });
    }

    const hashedPassword = await bcrypt.hash(newPassword, 10);
    db.prepare('UPDATE users SET password = ? WHERE id = ?').run(hashedPassword, req.user.id);
    res.json({ success: true });
  });

  // --- Admin User Management ---
  app.get('/api/admin/users', authenticate, isAdmin, (req, res) => {
    const users = db.prepare('SELECT id, name, email, role, created_at FROM users').all();
    res.json(users);
  });

  app.put('/api/admin/users/:id', authenticate, isAdmin, (req, res) => {
    const { role } = req.body;
    db.prepare('UPDATE users SET role = ? WHERE id = ?').run(role, req.params.id);
    res.json({ success: true });
  });

  app.delete('/api/admin/users/:id', authenticate, isAdmin, (req, res) => {
    db.prepare('DELETE FROM users WHERE id = ?').run(req.params.id);
    res.json({ success: true });
  });

  // --- Admin Settings Management ---
  app.get('/api/admin/settings', authenticate, isAdmin, (req, res) => {
    const settings = db.prepare('SELECT * FROM settings').all();
    const settingsObj = settings.reduce((acc: any, curr: any) => {
      acc[curr.key] = curr.value;
      return acc;
    }, {});
    res.json(settingsObj);
  });

  app.post('/api/admin/settings', authenticate, isAdmin, (req, res) => {
    const settings = req.body;
    const upsert = db.prepare('INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)');
    const transaction = db.transaction((data) => {
      for (const [key, value] of Object.entries(data)) {
        upsert.run(key, value);
      }
    });
    transaction(settings);
    res.json({ success: true });
  });

  // --- Public Settings ---
  app.get('/api/settings', (req, res) => {
    const settings = db.prepare('SELECT * FROM settings').all();
    const settingsObj = settings.reduce((acc: any, curr: any) => {
      acc[curr.key] = curr.value;
      return acc;
    }, {});
    res.json(settingsObj);
  });

  // --- OAuth Callback Hints (Add your manual logic here) ---
  app.get('/api/auth/google/callback', async (req, res) => {
    // 1. Exchange code for tokens
    // 2. Get user info from Google
    // 3. Find or create user in DB
    // 4. Set JWT cookie and redirect
    res.send('Google Auth Callback - Implement your manual logic here');
  });

  app.get('/api/auth/meta/callback', async (req, res) => {
    // 1. Exchange code for tokens
    // 2. Get user info from Meta
    // 3. Find or create user in DB
    // 4. Set JWT cookie and redirect
    res.send('Meta Auth Callback - Implement your manual logic here');
  });

  // --- OAuth Placeholder Routes ---
  app.get('/api/auth/google/url', (req, res) => {
    const redirectUri = `${process.env.APP_URL}/api/auth/google/callback`;
    const url = `https://accounts.google.com/o/oauth2/v2/auth?client_id=${process.env.GOOGLE_CLIENT_ID}&redirect_uri=${redirectUri}&response_type=code&scope=email%20profile`;
    res.json({ url });
  });

  app.get('/api/auth/meta/url', (req, res) => {
    const redirectUri = `${process.env.APP_URL}/api/auth/meta/callback`;
    const url = `https://www.facebook.com/v12.0/dialog/oauth?client_id=${process.env.META_CLIENT_ID}&redirect_uri=${redirectUri}&scope=email`;
    res.json({ url });
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.join(__dirname, 'dist')));
    app.get('*', (req, res) => res.sendFile(path.join(__dirname, 'dist', 'index.html')));
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
